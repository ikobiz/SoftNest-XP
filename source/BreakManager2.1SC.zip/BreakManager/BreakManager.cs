﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.Serialization;
using System.Diagnostics;
using Microsoft.Win32;
using System.Windows.Forms;

namespace BreakManager
{
    public class BreakManager
    {
        ////////////////////////////////////////////////////////////////////////
        #region Fields/Constants

        private const string CURRENT_DAY_TASKS_TEXT = "Current DAY tasks:";

        private State _state;
        private DateTime _lastActivityTime;
        private DateTime _startActivityTime;
        private DateTime _startBreakTime;
        private DateTime? _lastUpdateActivityTime;
        private Dictionary<string, TimeSpan> _currentDayTaskTimes;
        private Dictionary<string, TimeSpan> _currentActivityTaskTimes;
        private bool _isSessionLocked;
        private string _lastTaskName;
        private DateTime? _lastGotTaskName;

		private DateTime _lastBreakEvent; // Simulation

		public const string LOG_DIR = "Logs";
        public const string LOG_FILE_FORMAT = "{0:00}.{1:00}.{2:00} - {3}.txt";

        public TimeSpan TransitionToBreakTime = TimeSpan.FromMinutes(4);

        public bool IsAlarm1Shown { get; set; }
        public bool IsAlarm2Shown { get; set; }

        // Statistic
        public TimeSpan TotalBreakTime { get; private set; }
        public TimeSpan TotalActivityTime { get; private set; }
        public int BreakCount { get; private set; }
        public int ActivityCount { get; private set; }
        public DateTime StartDayTime { get; private set; }
        public TimeSpan LastBreakTime { get; private set; }

        public int SummaryStatisticDayCount { get; set; }

        // New
        public bool EmitActions { get; set; } = true;
		public int EmitCount { get; private set; }
        public int EmitTime { get; set; } = 2;

		#endregion

		////////////////////////////////////////////////////////////////////////
		#region Properties

		public TimeSpan CurrentActivityStateTime
        {
            get
            {
                if (_state == State.Activity || _state == State.TransitionToActivity)
                    return DateTime.Now - _startActivityTime;
                else
                    return TimeSpan.Zero;
            }
        }

        public TimeSpan CurrentBreakStateTime
        {
            get
            {
                if (_state == State.Break || _state == State.TransitionToActivity)
                    return DateTime.Now - _startBreakTime;
                else
                    return TimeSpan.Zero;
            }
        }

        public State CurrentState
        {
            get { return _state; }
        }

        public TimeSpan CurrentDayTime
        {
            get { return DateTime.Now - StartDayTime; }
        }

        public static string CurrentDayFileName
        {
            get
            {
                DateTime now = DateTime.Now;
                return string.Format(LOG_DIR + "\\" + LOG_FILE_FORMAT, now.Year, now.Month, now.Day,
                    now.DayOfWeek == DayOfWeek.Sunday ? 7 : (int)now.DayOfWeek);
            }
        }

        #endregion

        ////////////////////////////////////////////////////////////////////////
        #region Events

        public event Action<DateTime> BreakStateStarted;
        public event Action<TimeSpan> BreakStateEnded;

        public event Action<DateTime> ActivityStateStarted;
        public event Action<TimeSpan, string> ActivityStateEnded;

        #endregion

        ////////////////////////////////////////////////////////////////////////
        #region Constructors

        public BreakManager()
        {
            _startActivityTime = DateTime.Now;
            _lastActivityTime = DateTime.Now;
            _startBreakTime = DateTime.Now;
            StartDayTime = DateTime.Now;

            _currentDayTaskTimes = new Dictionary<string, TimeSpan>();
            _currentActivityTaskTimes = new Dictionary<string, TimeSpan>();

            _state = State.Activity;

            _lastBreakEvent = DateTime.Now;

			SystemEvents.SessionSwitch += new SessionSwitchEventHandler(SystemEvents_SessionSwitch);

            SummaryStatisticDayCount = 0;
        }

        #endregion

        ////////////////////////////////////////////////////////////////////////
        #region Inner Types

        public enum State
        {
            Activity,
            Break,
            TransitionToActivity // To protect starting the Activity state by random activities
        }

        #endregion

        ////////////////////////////////////////////////////////////////////////
        #region Public Methods

        public void Start()
        {
            _startActivityTime = DateTime.Now;
            _state = State.Activity;

            RegisterActivity();
            Update();

            ActivityStateStarted.Invoke(_startActivityTime);
        }

        public void RegisterActivity()
        {
            _lastActivityTime = DateTime.Now;
        }

        public void Update()
        {
            switch (_state)
            {
                case State.Activity:
                    UpdateActivityState();
                    break;

                case State.Break:
                    UpdateBreakState();
                    break;

                case State.TransitionToActivity:
                    UpdateTransitionToActivityState();
                    break;
            }
        }

        #region Statistic

        public string GetResultStatistic(bool isLogVersion)
        {
            TimeSpan activityTime = CurrentActivityStateTime + TotalActivityTime;
            TimeSpan breakTime = CurrentBreakStateTime + TotalBreakTime;
            TimeSpan totalAllTime = activityTime + breakTime;
            TimeSpan remainingTime = TimeSpan.FromHours(9) - CurrentDayTime;
            DateTime endTime = StartDayTime + TimeSpan.FromHours(9);

            // Working load
            int workingLoad = 0;
            if (activityTime.TotalMinutes > 0)
            {
                var breakTimeInMin = TotalBreakTime.TotalMinutes + breakTime.TotalMinutes;
                var actTimeInMin = TotalActivityTime.TotalMinutes + activityTime.TotalMinutes;
                workingLoad = 100 - (int)((breakTimeInMin / (actTimeInMin + breakTimeInMin)) * 100);
            }

            string result;

            string taskStastics = "\r\n" + GetAllTasksStatistic(isLogVersion);

            if (isLogVersion)
            {
                result =
                    "All:  " + string.Format("{0:00}:{1:00}", totalAllTime.Hours, totalAllTime.Minutes) + "\r\n\r\n" +
                    "Act:  " + string.Format("{0:00}:{1:00}", activityTime.Hours, activityTime.Minutes) + " (" + ActivityCount + " Act)" + "\r\n" +
                    "Br:   " + string.Format("{0:00}:{1:00}", breakTime.Hours, breakTime.Minutes) + "\r\n\r\n" +
                    "Load: " + workingLoad + "%";

                result += taskStastics;
            }
            else
            {
                result = "Statistic:\r\n\r\n" +
                    "TotalAllTime      = " + string.Format("{0:00}:{1:00}", totalAllTime.Hours, totalAllTime.Minutes) + "\r\n" +
                    "TotalActivityTime = " + string.Format("{0:00}:{1:00} (*)", activityTime.Hours, activityTime.Minutes) + "\r\n" +
                    "TotalBreakTime    = " + string.Format("{0:00}:{1:00} (-)", breakTime.Hours, breakTime.Minutes) + "\r\n\r\n" +

                    /*"RemainingTime     = " + string.Format("[{0:00}:{1:00}]", remainingTime.Hours, remainingTime.Minutes) + "\r\n" +*/

                    "Loading             = " + workingLoad + "%\r\n\r\n";/* +

                    //"ActivityCount     = " + ActivityCount + "\r\n" +
                    //"BreakCount        = " + BreakCount + "\r\n\r\n" +
                    "- Finish          = " + string.Format("({0:00}:{1:00})", endTime.Hour, endTime.Minute);*/

                // Day tasks statictic
                result += taskStastics;

                string curTask = GetCurrentTaskName();
                if (curTask != "Break Manager")
                    result += "\r\n\r\n(Cur task name: " + curTask + ")";
            }

            return result;
        }

        public void ClearStatictic()
        {
            TotalBreakTime = TimeSpan.Zero;
            TotalActivityTime = TimeSpan.Zero;
            BreakCount = 0;
            ActivityCount = 0;
            StartDayTime = DateTime.Now;

            _lastUpdateActivityTime = null;
            _currentDayTaskTimes.Clear();
            _currentActivityTaskTimes.Clear();
            
            _lastGotTaskName = null;
            _lastTaskName = null;
        }

        public static string GetCurrentTaskName()
        {
            var taskNameMap = new Dictionary<string, string>();

            taskNameMap["- Perforce"] = "Perforce";
            taskNameMap["- Far"] = "Far";
            taskNameMap["Mozilla Firefox"] = "Firefox";
            taskNameMap["Winamp"] = "Winamp";
            taskNameMap["Notepad++"] = "Notepad++";
            taskNameMap["NUnit"] = "NUnit";

            // Get active window title
            string currentWindowTitle = ActivityHelper.GetCurrentActivityName();

            Debug.WriteLine(currentWindowTitle);

            if (string.IsNullOrEmpty(currentWindowTitle))
                return null;

            string taskName = currentWindowTitle;

            bool isChanged = false;

            // Explorer
            if (taskName.Length > 2 && taskName[1] == ':' && !taskName.Contains(" - "))
            {
                taskName = "Explorer";
                isChanged = true;
            }

            if (!isChanged)
            {
                foreach (string key in taskNameMap.Keys)
                {
                    if (taskName.Contains(key))
                    {
                        isChanged = true;
                        taskName = taskNameMap[key];
                        break;
                    }
                }
            }

            if (!isChanged)
            {
                if (taskName.Contains(":"))
                {
                    taskName = taskName.Split(':')[0].Trim();
                    isChanged = true;
                }
            }

            if (!isChanged)
            {
                int separatorPos = taskName.IndexOf(" - ");
                if (separatorPos != -1)
                {
                    taskName = taskName.Substring(0, separatorPos);
                }

                // Correct Visual Studio titles like as "BreakManager (Running)"
                if (taskName.Contains("("))
                    taskName = taskName.Split('(')[0].Trim();

                // Remove a changed file mark
                taskName = taskName.Replace("*", "");
            }

            if (taskName.Length > 30)
                taskName = taskName.Substring(0, 28) + "..";

            return taskName;
        }

        #endregion

        #endregion

        ////////////////////////////////////////////////////////////////////////
        #region Private Methods

        #region Update states

        private void UpdateActivityState()
        {
			DateTime timeNow = DateTime.Now;

            // Process task times
            ProcessActiveWindowTimes(timeNow);

            TimeSpan currentIdleTime = timeNow - _lastActivityTime;

            TimeSpan transitionTime = TransitionToBreakTime;

            // Go to the break state
            if (currentIdleTime > transitionTime)
            {
                TimeSpan currentActivityStateTime = timeNow - _startActivityTime;
                TimeSpan activityTime = currentActivityStateTime - currentIdleTime;

                _startBreakTime = _lastActivityTime;
                _state = State.Break;

                // Activity statistic
                if (activityTime > TimeSpan.FromMinutes(3)) // Do not count small activities
                {
                    TotalActivityTime += activityTime;
                    ActivityCount++;
                }

                // Events
                string info = GetCurrentActivityTaskStatistic(activityTime);
                ActivityStateEnded.Invoke(activityTime, info);

                BreakStateStarted.Invoke(_startBreakTime);

                // Reset current activity task times
                _currentActivityTaskTimes.Clear();
                _lastUpdateActivityTime = null;

                _lastTaskName = null;
                _lastGotTaskName = null;

                return;
            }
        }

        private void UpdateBreakState()
        {
			// Some activity is detected
			// NEW 2024: Checking _isSessionLocked
			if (!_isSessionLocked && _lastActivityTime != _startBreakTime)
            {
                _startActivityTime = _lastActivityTime;
                _state = State.TransitionToActivity;
            }

            // NEW: During the break state, try to emitate some activity
            if (EmitActions &&
                DateTime.Now - _lastBreakEvent > TimeSpan.FromSeconds(30) &&     // Perform every 30 seconds
				DateTime.Now - _startBreakTime < TimeSpan.FromHours(EmitTime) && // Don't emitate after some hours of a break
				DateTime.Now.Hour >= 9 && DateTime.Now.Hour < 19)                // Emitate only during the day (9am - 7pm)
            {
                EmitCount++;

                _lastBreakEvent = DateTime.Now;

                try
                {
                    SendKeys.SendWait("%"); // "%": Send Alt key
                    //SendKeys.SendWait("+"); // "+": Send Shift key
                }
                catch
                {
                }
			}
		}

		private void UpdateTransitionToActivityState()
        {
            TimeSpan idleTime = DateTime.Now - _lastActivityTime;
            TimeSpan stateTime = DateTime.Now - _startActivityTime;

            TimeSpan currentBreakTime = DateTime.Now - _startBreakTime;
            LastBreakTime = currentBreakTime; // Statistic

            // It is a break, go to the Break state again
            if (idleTime > TimeSpan.FromSeconds(10))
            {
                _lastActivityTime = _startBreakTime;
                _state = State.Break;
            }
            // It was an Activity state, go to it
            else if (stateTime > TimeSpan.FromSeconds(20))
            {
                _state = State.Activity;

                // Init the activity state
                IsAlarm1Shown = false;
                IsAlarm2Shown = false;

                TimeSpan breakTime = currentBreakTime - stateTime;

                // The break statistic
                if (breakTime < TimeSpan.FromHours(4)) // Do not count long breaks
                {
                    TotalBreakTime += breakTime;
                    BreakCount++;
                }

                // Events
                BreakStateEnded.Invoke(breakTime);
                ActivityStateStarted.Invoke(_startActivityTime);

                LastBreakTime = breakTime;

                EmitCount = 0;
            }
        }

        private void SystemEvents_SessionSwitch(object sender, SessionSwitchEventArgs e)
        {
            if (e.Reason == SessionSwitchReason.SessionLock)
            {
                _isSessionLocked = true;
            }
            else if (e.Reason == SessionSwitchReason.SessionUnlock)
            {
				_isSessionLocked = false;
			}
        }

        #endregion

        #region Task statistic

        private void ProcessActiveWindowTimes(DateTime timeNow)
        {
            if (_lastUpdateActivityTime == null)
            {
                _lastUpdateActivityTime = timeNow;
                return;
            }

            // Get a 'frame time'
            TimeSpan frameTime = timeNow - _lastUpdateActivityTime.Value;
            _lastUpdateActivityTime = timeNow;

            // Task name
            string taskName = GetCurrentTaskName();

            if (string.IsNullOrEmpty(taskName))
            {
                if (_lastGotTaskName.HasValue && timeNow - _lastGotTaskName < TimeSpan.FromSeconds(5))
                    taskName = _lastTaskName;
                else
                    taskName = "(not detected)";
            }
            else
            {
                _lastTaskName = taskName;
                _lastGotTaskName = timeNow;
            }

            // Accumulate frame times for the day
            AddTimeToTaskDict(_currentDayTaskTimes, taskName, frameTime);

            // Accumulate frame times for the current activity 
            AddTimeToTaskDict(_currentActivityTaskTimes, taskName, frameTime);
        }

        private static void AddTimeToTaskDict(Dictionary<string, TimeSpan> dict, string taskName, TimeSpan time)
        {
            if (!dict.ContainsKey(taskName))
                dict.Add(taskName, TimeSpan.Zero);

            dict[taskName] += time;
        }

        private string GetAllTasksStatistic(bool isLogVersion)
        {
            string result = string.Empty;

            const string SEPARATOR = "\r\n-----------------------\r\n";

            if (_currentActivityTaskTimes != null && _currentActivityTaskTimes.Count > 0)
                result += SEPARATOR + "Current activity tasks:\r\n\r\n" + GetTaskListStatistic(_currentActivityTaskTimes, 2);

            if (_currentDayTaskTimes != null && _currentDayTaskTimes.Count > 0)
                result += SEPARATOR + CURRENT_DAY_TASKS_TEXT + "\r\n\r\n" + GetTaskListStatistic(_currentDayTaskTimes, 5, false, true);

            if (!isLogVersion && SummaryStatisticDayCount > 0)
            {
                var summaryTaskTimes = GetTaskTimesFromLastDays(SummaryStatisticDayCount);

                if (summaryTaskTimes != null && summaryTaskTimes.Count > 0)
                {
                    // TODO: add day  range
                    result += SEPARATOR + string.Format("Summary activity tasks for {0} days:\r\n\r\n", SummaryStatisticDayCount) +
                        GetTaskListStatistic(summaryTaskTimes, 60, false, false);
                }
            }

            return result;
        }

        private static string GetTaskListStatistic(Dictionary<string, TimeSpan> taskTimes, int minTimeInMinutes)
        {
            return GetTaskListStatistic(taskTimes, minTimeInMinutes, true, true);
        }

        private static string GetTaskListStatistic(Dictionary<string, TimeSpan> taskTimes,
            int minTimeInMinutes, bool showOtherTime, bool showAllTime)
        {
            string result = string.Empty;

            var taskList = taskTimes.ToList();
            taskList.Sort((p1, p2) => p2.Value.CompareTo(p1.Value));

            int taskNumber = 1;
            TimeSpan otherTime = TimeSpan.Zero;

            const string TASK_FORMAT = "{0}) {1}: [{2:00}:{3:00}]";

            foreach (var pair in taskList)
            {
                TimeSpan time = pair.Value;

                if (time.TotalMinutes < minTimeInMinutes)
                {
                    otherTime += time;
                    continue;
                }

                result += string.Format(TASK_FORMAT + "\r\n",
                    taskNumber++, pair.Key, time.Hours, time.Minutes + (time.Seconds > 30 ? 1 : 0));
            }

            if (showOtherTime && otherTime.TotalMinutes > 1)
            {
                result += string.Format(TASK_FORMAT + "\r\n",
                    taskNumber, "Other", otherTime.Hours, otherTime.Minutes + (otherTime.Seconds > 30 ? 1 : 0));
            }

            // To check
            if (showAllTime)
            {
                TimeSpan allTime = TimeSpan.Zero;
                foreach (var pair in taskList)
                    allTime += pair.Value;

                result += string.Format("\r\n   ={0:00}:{1:00}\r\n", allTime.Hours, allTime.Minutes);
            }

            return result;
        }

        private string GetCurrentActivityTaskStatistic(TimeSpan activityTime)
        {
            if (activityTime.TotalMinutes < 5)
                return string.Empty;

            // Find a first task with max time
            string taskWithMaxTime1 = null;
            TimeSpan maxTime1 = TimeSpan.Zero;

            foreach (string taskName in _currentActivityTaskTimes.Keys)
            {
                TimeSpan time = _currentActivityTaskTimes[taskName];
                if (time > maxTime1)
                {
                    maxTime1 = time;
                    taskWithMaxTime1 = taskName;
                }
            }

            if (taskWithMaxTime1 == null)
                return string.Empty;

            // Find a second task with max time
            string taskWithMaxTime2 = null;
            TimeSpan maxTime2 = TimeSpan.Zero;

            foreach (string taskName in _currentActivityTaskTimes.Keys)
            {
                if (taskName == taskWithMaxTime1)
                    continue;

                TimeSpan time = _currentActivityTaskTimes[taskName];
                if (time > maxTime2)
                {
                    maxTime2 = time;
                    taskWithMaxTime2 = taskName;
                }
            }

            // Show results
            string result = "";

            const string INFO_FORMAT = "[:{1:00}] {0}({2}%)";
            const string INFO_FORMAT_2 = "[:{1:00}] {0}";

            int maxTaskTimeToShow1 = 7;
            int maxTaskTimeToShow2 = 5;

            if (maxTime1.TotalMinutes > maxTaskTimeToShow1)
            {
                int persents = (int)(maxTime2.TotalMinutes / activityTime.TotalMinutes * 100);

                if (persents > 70 && maxTime1.TotalMinutes > 30)
                    result += string.Format(INFO_FORMAT, taskWithMaxTime1, (int)maxTime1.TotalMinutes, persents);
                else
                    result += string.Format(INFO_FORMAT_2, taskWithMaxTime1, (int)maxTime1.TotalMinutes);

                if (maxTime2.TotalMinutes > maxTaskTimeToShow2)
                {
                    if (taskWithMaxTime2 != null)
                    {
                        int persents2 = (int)(maxTime2.TotalMinutes / activityTime.TotalMinutes * 100);

                        if (persents > 25 && maxTime2.TotalMinutes > 15)
                            result += "; " + string.Format(INFO_FORMAT, taskWithMaxTime2, (int)maxTime2.TotalMinutes, persents);
                        else
                            result += "; " + string.Format(INFO_FORMAT_2, taskWithMaxTime2, (int)maxTime2.TotalMinutes);
                    }
                }
            }

            return result;
        }

        #endregion

        #region Summary statistic from log files

        private Dictionary<string, TimeSpan> GetTaskTimesFromLastDays(int dayCount)
        {
            List<string> fileNames = GetFileNamesFromLastDays(dayCount);
            
            var result = GetTaskTimesFromFiles(fileNames);

            // Merge with the current day tasks
            foreach (string taskName in _currentActivityTaskTimes.Keys)
            {
                if (!result.ContainsKey(taskName))
                    result.Add(taskName, TimeSpan.Zero);

                result[taskName] += _currentActivityTaskTimes[taskName];
            }

            return result;
        }

        private static List<string> GetFileNamesFromLastDays(int dayCount)
        {
            return GetFileNamesByDateRange(DateTime.Now - TimeSpan.FromDays(dayCount), DateTime.Now);
        }

        private static List<string> GetFileNamesByDateRange(DateTime startDate, DateTime endDate)
        {
            List<string> result = new List<string>();

            if (!Directory.Exists(LOG_DIR))
                return result;

            var files = Directory.GetFiles(LOG_DIR, "*.txt");
            foreach (string fileName in files)
            {
                // 2016.03.21 - 1.txt
                string[] parts = Path.GetFileNameWithoutExtension(fileName).Split(". -".ToCharArray());

                DateTime time;

                try
                {
                    int year = int.Parse(parts[0]);
                    int month = int.Parse(parts[1]);
                    int day = int.Parse(parts[2]);

                    time = new DateTime(year, month, day);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex);
                    continue;
                }

                if (time >= startDate && time <= endDate)
                    result.Add(fileName);
            }

            return result;
        }

        private static Dictionary<string, TimeSpan> GetTaskTimesFromFiles(List<string> fileNames)
        {
            Dictionary<string, TimeSpan> result = new Dictionary<string, TimeSpan>();

            foreach (string fileName in fileNames)
            {
                var timeFromFile = GetTaskTimesFromFile(fileName);
                if (timeFromFile.Count == 0)
                    continue;

                // Merge with the result
                foreach (string taskName in timeFromFile.Keys)
                {
                    if (!result.ContainsKey(taskName))
                        result.Add(taskName, TimeSpan.Zero);

                    result[taskName] += timeFromFile[taskName];
                }
            }

            return result;
        }

        private static Dictionary<string, TimeSpan> GetTaskTimesFromFile(string fileName)
        {
            Dictionary<string, TimeSpan> result = new Dictionary<string, TimeSpan>();

            string[] allLines;

            try
            {
                allLines = File.ReadAllLines(fileName);
            }
            catch
            {
                return result;
            }

            bool readingTaskTimes = false;

            #region Log example

            // Current DAY tasks:
            // 1) F2FMaker: [01:46]
            // 2) Firefox: [00:48]
            // 3) 48_DeleteAsciiOrKanjiCharacter: [00:42]
            // 4) (not detected): [00:16]
            // 10) Other: [00:23]

            #endregion

            for (int i = 0; i < allLines.Length; i++)
            {
                string line = allLines[i].Trim();

                if (line.Contains(CURRENT_DAY_TASKS_TEXT))
                    readingTaskTimes = true;

                if (readingTaskTimes)
                {
                    if (line.Contains(")") && line.Contains("["))
                    {
                        string[] parts = line.Split(")[]".ToCharArray());
                        if (parts.Length < 3)
                            continue;

                        string taskName = parts[1].Trim(':', ' ');
                        string timeString = parts[2];

                        string[] timeParts = timeString.Split(':');
                        if (timeParts.Length != 2)
                            continue;

                        int hours;
                        int minutes;

                        if (!int.TryParse(timeParts[0], out hours))
                            continue;

                        if (!int.TryParse(timeParts[1], out minutes))
                            continue;

                        TimeSpan time = TimeSpan.FromHours(hours) + TimeSpan.FromMinutes(minutes);

                        if (!result.ContainsKey(taskName))
                            result.Add(taskName, TimeSpan.Zero);

                        result[taskName] += time;
                    }
                }
            }

            return result;
        }

        #endregion

        #endregion
    }
}

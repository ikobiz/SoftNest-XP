﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace BreakManager
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            //var res = BreakManager.GetTaskTimesFromFiles(new List<string> {
            //    @"E:\PersonalData\ProgramFiles\BreakManager\Logs\2016.03.21.txt",
            //    @"E:\PersonalData\ProgramFiles\BreakManager\Logs\2016.03.20.txt",
            //});
            //return;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BreakManager
{
	public static class ActivityHelper
	{
		private static string _lastRemoteActivityId;
		private static string _lastLocalActivityId;

		private static bool _isRemoteActivity;

		public static string GetLastUserActivityId()
		{
			// Check remote
			//string remoteActivityId = RemoteActivityDetector.GetRemoteActivity();
			string remoteActivityId = null; // Don't use

			if (remoteActivityId != null && _lastRemoteActivityId != remoteActivityId)
			{
				_lastRemoteActivityId = remoteActivityId;
				_isRemoteActivity = true;
			}

			// Check local
			string localActivityId = IdleDetector.GetLastUserActivityTime().ToString();

			if (_lastLocalActivityId != localActivityId)
			{
				_lastLocalActivityId = localActivityId;
				_isRemoteActivity = false;
			}

			// Return result
			if (_isRemoteActivity)
			{
				return _lastRemoteActivityId;
			}
			else
			{
				return _lastLocalActivityId;
			}
		}

		public static string GetCurrentActivityName()
		{
			if (_isRemoteActivity)
			{
				return "MacBook Pro";
			}
			else
			{
				return ActiveWindowDetector.GetActiveWindowTitle();
			}
		}
	}
}

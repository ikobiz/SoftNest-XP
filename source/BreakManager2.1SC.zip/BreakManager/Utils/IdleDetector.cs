﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace BreakManager
{
    // Info was taken from - http://forum.codecall.net/topic/69801-user-idle-detection/
    public static class IdleDetector
    {
        [DllImport("user32.dll")]
        private static extern Boolean GetLastInputInfo(ref tagLASTINPUTINFO plii);

        private struct tagLASTINPUTINFO
        {
            public uint cbSize;
            public Int32 dwTime;
        }

        public static int GetLastUserActivityTime()
        {
            tagLASTINPUTINFO LastInput = new tagLASTINPUTINFO();
            LastInput.cbSize = (uint)Marshal.SizeOf(LastInput);
            LastInput.dwTime = 0;

            if (GetLastInputInfo(ref LastInput))
            {
                return LastInput.dwTime;
            }

            return -1;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;

namespace BreakManager
{
	class RemoteActivityDetector
	{
        public static string GetRemoteActivity()
        {
            return DownloadTextFromWeb("https://test-azure-app-1.azurewebsites.net/get-detecting-id");
        }

        private static string DownloadTextFromWeb(string url)
        {
            if (string.IsNullOrEmpty(url))
                throw new ArgumentNullException(url);

            try
            {
                WebClient c = new WebClient();

                var result = c.DownloadString(url);

                return result;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}

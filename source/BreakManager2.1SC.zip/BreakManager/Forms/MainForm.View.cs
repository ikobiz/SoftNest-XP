﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BreakManager
{
	public partial class MainForm
	{
        private class View
        {
            public View(MainForm form)
            {
                _form = form;
            }

            private MainForm _form;

            public int TransitionToBreakTime
            {
                get { return (int)_form.numericUpDownCheckBreakTime.Value; }
                set { _form.numericUpDownCheckBreakTime.Value = value; }
            }

            //public event Action TransitionToBreakTimeChanged
            //{
            //    add { _form.numericUpDownCheckBreakTime.ValueChanged += delegate { value.Invoke(); }; }
            //    remove { }
            //}

            public void Load()
            {
            }
        }
	}
}

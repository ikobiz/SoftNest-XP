﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace BreakManager
{
    public partial class SmallWindow : Form
    {
        public SmallWindow()
        {
            InitializeComponent();

            MouseDown += HandleMouseDown;
            
            // Handle inner controls also
            label1.MouseDown += HandleMouseDown; 

        }

        public event Action ShowParentWindow;

        public string StatusText
        {
            set { label1.Text = value; }
        }

        private void DoShowParentWindow(bool hideThis)
        {
            if (ShowParentWindow != null)
                ShowParentWindow.Invoke();

            if (hideThis)
                this.Visible = false;
        }

        #region Move a window without the border

        // http://stackoverflow.com/questions/4577141/move-window-without-border

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        private void HandleMouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
            else if (e.Button == MouseButtons.Right)
            {
                DoShowParentWindow(true);
            }
            else if (e.Button == MouseButtons.Middle)
            {
                DoShowParentWindow(false);
            }
        }

        #endregion
    }
}

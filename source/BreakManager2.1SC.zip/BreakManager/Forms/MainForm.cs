﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using BreakManager.Properties;
using System.IO;

namespace BreakManager
{
    public partial class MainForm : Form
    {
        #region Private Fields/Properties

        private BreakManager _breakManager;
        private Timer _updateTimer;
        private bool _isMessageBoxVisible;
        private string _prevActivityId;
        private SmallWindow _smallWindow;
        private string _prevDayFileName;
        private DateTime _lastUpdateStatTime;

        #endregion

        public MainForm()
        {
            InitializeComponent();
            
            InitBreakManager();

            // Load the last log
            if (File.Exists(BreakManager.CurrentDayFileName))
                textBox1.Text = File.ReadAllText(BreakManager.CurrentDayFileName);

            // The small window
            _smallWindow = new SmallWindow();
            _smallWindow.ShowParentWindow += delegate { Visible = true; };
        }

        private void InitBreakManager()
        {
            _breakManager = new BreakManager();

            comboBox1.SelectedIndex = comboBox1.Items.IndexOf("25");
            comboBox2.SelectedIndex = comboBox1.Items.IndexOf("30");

            int checkBreakTime = Settings.Default.CheckBreakTime;
            _breakManager.TransitionToBreakTime = TimeSpan.FromMinutes(checkBreakTime);
            numericUpDownCheckBreakTime.Value = _breakManager.TransitionToBreakTime.Minutes;
            numericUpDownSumStatDayCount.Value = _breakManager.SummaryStatisticDayCount;

            // Updating
            _updateTimer = new Timer();
            
            _updateTimer.Interval = 1000;
            //_updateTimer.Interval = 5000;

            DateTime prevTime = DateTime.Now;

            _updateTimer.Tick += delegate
            {
                if (DateTime.Now - prevTime > TimeSpan.FromSeconds(3))
                {
                    UpdateBreakManager();
                    prevTime = DateTime.Now;
                }
            };

            // Logging
            _breakManager.ActivityStateStarted += time => textBox1.Text +=
                string.Format("\r\nACTIVITY started: {0:00}:{1:00}\t", time.Hour, time.Minute);

            _breakManager.ActivityStateEnded += (time, info) =>
            {
                string text = string.Format("[{0:00}:{1:00}]", time.Hours, time.Minutes) + "\t" + GetTimeVisualIndicator(time, '*', true);
                text = text.PadRight(30);
                text += info;
                textBox1.Text += text + "\r\n";
            };

            _breakManager.BreakStateStarted += time => textBox1.Text +=
                string.Format("BREAK    started: {0:00}:{1:00}\t", time.Hour, time.Minute);

            _breakManager.BreakStateEnded += time => textBox1.Text +=
                string.Format("[{0:00}:{1:00}]", time.Hours, time.Minutes) + "\t" + GetTimeVisualIndicator(time, '-', false) + "\r\n";

            // Save the log
            _breakManager.BreakStateEnded += delegate { SaveLog(true); };
            _breakManager.ActivityStateStarted += delegate { SaveLog(false); };

            // New
            checkBoxEmit.Checked = Settings.Default.Emit;
            _breakManager.EmitActions = Settings.Default.Emit;

			numericUpDownEmitTime.Value = Settings.Default.EmitTime;
            _breakManager.EmitTime = Settings.Default.EmitTime;

			// Start
			_breakManager.Start();
            _updateTimer.Enabled = true;
        }

        #region Updating

        private void UpdateBreakManager()
        {
            string curActivityId = ActivityHelper.GetLastUserActivityId();
            
            string curActivityName = ActivityHelper.GetCurrentActivityName();
            bool isLockScreen = (curActivityName == "Windows Default Lock Screen");

            if (curActivityId != _prevActivityId && !isLockScreen)
            {
                _prevActivityId = curActivityId;
                _breakManager.RegisterActivity();
            }

            _breakManager.Update();

            UpdateStatusBar();
            UpdateSmallWindow();
            UpdateAlarms();

            // Update the statistic window each 1 minutes
            if (!textBoxStatistic.Focused || DateTime.Now - _lastUpdateStatTime > TimeSpan.FromMinutes(1))
            {
                _lastUpdateStatTime = DateTime.Now;
                textBoxStatistic.Text = _breakManager.GetResultStatistic(false);
            }
        }

        private void UpdateStatusBar()
        {
            try
            {
                Invoke(new Action(() =>
                {
                    statusLabelBreakTime.Text = _breakManager.CurrentState != BreakManager.State.Activity ?
                        PrintTime(_breakManager.CurrentBreakStateTime, true) : "00";

                    statusLabelActivityTime.Text = _breakManager.CurrentState != BreakManager.State.Break ?
                        PrintTime(_breakManager.CurrentActivityStateTime, true) : "00";

                    statusLabelState.Text = _breakManager.CurrentState.ToString();

                    notifyIcon1.Text = "Activity time: " + statusLabelActivityTime.Text;

                    statusLabelEmitCount.Text = _breakManager.EmitCount.ToString();
                }));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exc: " + ex.Message);
            }
        }

        private void UpdateSmallWindow()
        {
            if (_smallWindow.Visible)
            {
                int alarm1Value;
                int.TryParse((string)comboBox1.Text, out alarm1Value);

                TimeSpan remainingTime = TimeSpan.FromHours(9) - _breakManager.CurrentDayTime + TimeSpan.FromMinutes(1);

				/*
                const string FORMAT = "{0:00} / {1} [{2}:{3:00}/{4}:{5:00}] <{6:00}>";

                _smallWindow.StatusText = string.Format(FORMAT,
                    _breakManager.CurrentActivityStateTime.Minutes, // 0
                    alarm1Value, // 1
                    _breakManager.CurrentDayTime.Hours, // 2
                    _breakManager.CurrentDayTime.Minutes, // 3
                    remainingTime.Hours, // 4
                    remainingTime.Minutes, // 5
                    _breakManager.LastBreakTime.Minutes); // 6
                */

                // NEW
				const string FORMAT = "{0:00} / {1} <{2:00}>";

				_smallWindow.StatusText = string.Format(FORMAT,
					_breakManager.CurrentActivityStateTime.Minutes, // 0
					alarm1Value, // 1
					_breakManager.LastBreakTime.Minutes); // 6

			}
		}

        private void UpdateAlarms()
        {
            if (!_isMessageBoxVisible &&
                _breakManager.CurrentState == BreakManager.State.Activity &&
                !comboBox1.Focused && !comboBox2.Focused)
            {
                if (!_breakManager.IsAlarm1Shown)
                {
                    int alarm1Value;
                    if (int.TryParse((string)comboBox1.Text, out alarm1Value))
                    {
                        if (_breakManager.CurrentActivityStateTime.TotalMinutes > alarm1Value)
                        {
                            _breakManager.IsAlarm1Shown = true;

                            TopMost = true;
                            _isMessageBoxVisible = true;

                            MessageBox.Show(this, string.Format("Session time = {0}",
                                (int)_breakManager.CurrentActivityStateTime.TotalMinutes),
                                "Break Manager", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                            TopMost = false;
                            _isMessageBoxVisible = false;
                        }
                    }
                }

                if (!_breakManager.IsAlarm2Shown)
                {
                    int alarm2Value;
                    if (int.TryParse((string)comboBox2.Text, out alarm2Value))
                    {
                        if (_breakManager.CurrentActivityStateTime.TotalMinutes > alarm2Value)
                        {
                            _breakManager.IsAlarm2Shown = true;

                            TopMost = true;
                            _isMessageBoxVisible = true;

                            MessageBox.Show(this, string.Format("Session time = {0} !!!!! A break required!!!",
                                (int)_breakManager.CurrentActivityStateTime.TotalMinutes),
                                "Break Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);

                            TopMost = false;
                            _isMessageBoxVisible = false;
                        }
                    }
                }
            }
        }

        #endregion

        #region Utils

        private static string PrintTime(TimeSpan time, bool printSeconds)
        {
            if (printSeconds)
                return string.Format("{0:00}:{1:00}:{2:00}", time.Hours, time.Minutes, time.Seconds);
            else
                return string.Format("{0:00}:{1:00}", time.Hours, time.Minutes);
        }

        private static string GetTimeVisualIndicator(TimeSpan time, char simbol, bool ceiling)
        {
            const int MINUTE_POINT_VALUE = 5;

            int minutesPointCount = (int)time.TotalMinutes / MINUTE_POINT_VALUE + (ceiling ? 1 : 0);

            string result = "";

            if (minutesPointCount > 0)
                result = new string(simbol, minutesPointCount);

            return result;
        }

        #endregion

        #region Control Handlers

        private void notifyIcon1_DoubleClick(object sender, EventArgs e)
        {
            Visible = true;
        }

        private void buttonHide_Click(object sender, EventArgs e)
        {
            Visible = false;
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Delete the log ?", "Break Manager", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                textBox1.Text = "";
                _breakManager.ClearStatictic();

                if (File.Exists(BreakManager.CurrentDayFileName))
                    File.Move(BreakManager.CurrentDayFileName, BreakManager.CurrentDayFileName + "-removed-" + DateTime.Now.ToFileTime());
            }
        }

        private void numericUpDownCheckBreakTime_ValueChanged(object sender, EventArgs e)
        {
            Settings.Default.CheckBreakTime = (int)numericUpDownCheckBreakTime.Value;
            Settings.Default.Save();

            _breakManager.TransitionToBreakTime = TimeSpan.FromMinutes((int)numericUpDownCheckBreakTime.Value);
        }

        private void numericUpDownSumStatDayCount_ValueChanged(object sender, EventArgs e)
        {
            _breakManager.SummaryStatisticDayCount = (int)numericUpDownSumStatDayCount.Value;

            // Force update statistic window
            _lastUpdateStatTime = DateTime.Now;
        }

        private void buttonMinimize_Click(object sender, EventArgs e)
        {
            Visible = false;
            _smallWindow.Visible = true;
        }

        private void buttonClearStatistic_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Clear the statistic ?", "Break Manager", MessageBoxButtons.YesNo) == DialogResult.Yes)
                _breakManager.ClearStatictic();
        }

		private void checkBoxEmit_CheckedChanged(object sender, EventArgs e)
		{
			Settings.Default.Emit = checkBoxEmit.Checked;
			Settings.Default.Save();

			_breakManager.EmitActions = checkBoxEmit.Checked;
		}

		private void numericUpDownEmitTime_ValueChanged(object sender, EventArgs e)
		{
            Settings.Default.EmitTime = (int)numericUpDownEmitTime.Value;
			Settings.Default.Save();

            _breakManager.EmitTime = (int)numericUpDownEmitTime.Value;
		}

		#endregion

		private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Settings.Default.Save();
            SaveLog(false);

            //_breakManager.Save();
        }

        private void SaveLog(bool savePrevDay)
        {
            string dir = Path.GetDirectoryName(BreakManager.CurrentDayFileName);

            if (!Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            try
            {
                string text = textBox1.Text;

                string fileName;

                if (savePrevDay && _prevDayFileName != BreakManager.CurrentDayFileName)
                {
                    fileName = _prevDayFileName;

                    // Append statictic
                    text += "\r\n\r\n" + _breakManager.GetResultStatistic(true);
                }
                else
                {
                    fileName = BreakManager.CurrentDayFileName;
                }

                File.WriteAllText(fileName, text);
            }
            catch { }

            if (_prevDayFileName == null)
            {
                _prevDayFileName = BreakManager.CurrentDayFileName;
            }
            else if (_prevDayFileName != BreakManager.CurrentDayFileName)
            {
                _prevDayFileName = BreakManager.CurrentDayFileName;

                textBox1.Text = "";
                _breakManager.ClearStatictic();
            }
        }
	}
}

﻿namespace BreakManager
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
			this.statusLabelActivityTime = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
			this.statusLabelBreakTime = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
			this.statusLabelState = new System.Windows.Forms.ToolStripStatusLabel();
			this.statusLabelCurWindow = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
			this.statusLabelEmitCount = new System.Windows.Forms.ToolStripStatusLabel();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.comboBox2 = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
			this.buttonClear = new System.Windows.Forms.Button();
			this.numericUpDownCheckBreakTime = new System.Windows.Forms.NumericUpDown();
			this.label3 = new System.Windows.Forms.Label();
			this.buttonMinimize = new System.Windows.Forms.Button();
			this.textBoxStatistic = new System.Windows.Forms.TextBox();
			this.buttonClearStatistic = new System.Windows.Forms.Button();
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.panel1 = new System.Windows.Forms.Panel();
			this.numericUpDownEmitTime = new System.Windows.Forms.NumericUpDown();
			this.checkBoxEmit = new System.Windows.Forms.CheckBox();
			this.numericUpDownSumStatDayCount = new System.Windows.Forms.NumericUpDown();
			this.label4 = new System.Windows.Forms.Label();
			this.buttonHide = new System.Windows.Forms.Button();
			this.statusStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownCheckBreakTime)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownEmitTime)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownSumStatDayCount)).BeginInit();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox1.Font = new System.Drawing.Font("Courier New", 10.18868F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox1.Location = new System.Drawing.Point(0, 0);
			this.textBox1.Margin = new System.Windows.Forms.Padding(4);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.ReadOnly = true;
			this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.textBox1.Size = new System.Drawing.Size(896, 595);
			this.textBox1.TabIndex = 0;
			this.textBox1.WordWrap = false;
			// 
			// statusStrip1
			// 
			this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.statusLabelActivityTime,
            this.toolStripStatusLabel2,
            this.statusLabelBreakTime,
            this.toolStripStatusLabel3,
            this.statusLabelState,
            this.statusLabelCurWindow,
            this.toolStripStatusLabel4,
            this.statusLabelEmitCount});
			this.statusStrip1.Location = new System.Drawing.Point(0, 697);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
			this.statusStrip1.Size = new System.Drawing.Size(1379, 30);
			this.statusStrip1.TabIndex = 1;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// toolStripStatusLabel1
			// 
			this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
			this.toolStripStatusLabel1.Size = new System.Drawing.Size(98, 24);
			this.toolStripStatusLabel1.Text = "Activity Time:";
			// 
			// statusLabelActivityTime
			// 
			this.statusLabelActivityTime.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.statusLabelActivityTime.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
			this.statusLabelActivityTime.Name = "statusLabelActivityTime";
			this.statusLabelActivityTime.Size = new System.Drawing.Size(50, 24);
			this.statusLabelActivityTime.Text = "0 min";
			// 
			// toolStripStatusLabel2
			// 
			this.toolStripStatusLabel2.Margin = new System.Windows.Forms.Padding(10, 3, 0, 2);
			this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
			this.toolStripStatusLabel2.Size = new System.Drawing.Size(86, 25);
			this.toolStripStatusLabel2.Text = "Break Time:";
			// 
			// statusLabelBreakTime
			// 
			this.statusLabelBreakTime.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.statusLabelBreakTime.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
			this.statusLabelBreakTime.Name = "statusLabelBreakTime";
			this.statusLabelBreakTime.Size = new System.Drawing.Size(50, 24);
			this.statusLabelBreakTime.Text = "0 min";
			// 
			// toolStripStatusLabel3
			// 
			this.toolStripStatusLabel3.Margin = new System.Windows.Forms.Padding(10, 3, 0, 2);
			this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
			this.toolStripStatusLabel3.Size = new System.Drawing.Size(46, 25);
			this.toolStripStatusLabel3.Text = "State:";
			// 
			// statusLabelState
			// 
			this.statusLabelState.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.statusLabelState.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
			this.statusLabelState.Name = "statusLabelState";
			this.statusLabelState.Size = new System.Drawing.Size(49, 24);
			this.statusLabelState.Text = "None";
			// 
			// statusLabelCurWindow
			// 
			this.statusLabelCurWindow.Name = "statusLabelCurWindow";
			this.statusLabelCurWindow.Size = new System.Drawing.Size(0, 24);
			// 
			// toolStripStatusLabel4
			// 
			this.toolStripStatusLabel4.Margin = new System.Windows.Forms.Padding(10, 4, 0, 2);
			this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
			this.toolStripStatusLabel4.Size = new System.Drawing.Size(42, 24);
			this.toolStripStatusLabel4.Text = "Emit:";
			// 
			// statusLabelEmitCount
			// 
			this.statusLabelEmitCount.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.statusLabelEmitCount.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
			this.statusLabelEmitCount.Name = "statusLabelEmitCount";
			this.statusLabelEmitCount.Size = new System.Drawing.Size(21, 24);
			this.statusLabelEmitCount.Text = "0";
			// 
			// comboBox1
			// 
			this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
            "<None>",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "60"});
			this.comboBox1.Location = new System.Drawing.Point(1039, 12);
			this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(160, 24);
			this.comboBox1.TabIndex = 2;
			// 
			// comboBox2
			// 
			this.comboBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.comboBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.comboBox2.FormattingEnabled = true;
			this.comboBox2.Items.AddRange(new object[] {
            "<None>",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "60"});
			this.comboBox2.Location = new System.Drawing.Point(1039, 46);
			this.comboBox2.Margin = new System.Windows.Forms.Padding(4);
			this.comboBox2.Name = "comboBox2";
			this.comboBox2.Size = new System.Drawing.Size(160, 24);
			this.comboBox2.TabIndex = 3;
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(953, 20);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(55, 16);
			this.label1.TabIndex = 4;
			this.label1.Text = "Alarm 1:";
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(953, 53);
			this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(55, 16);
			this.label2.TabIndex = 4;
			this.label2.Text = "Alarm 2:";
			// 
			// notifyIcon1
			// 
			this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
			this.notifyIcon1.Visible = true;
			this.notifyIcon1.DoubleClick += new System.EventHandler(this.notifyIcon1_DoubleClick);
			// 
			// buttonClear
			// 
			this.buttonClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.buttonClear.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
			this.buttonClear.Location = new System.Drawing.Point(16, 12);
			this.buttonClear.Margin = new System.Windows.Forms.Padding(4);
			this.buttonClear.Name = "buttonClear";
			this.buttonClear.Size = new System.Drawing.Size(117, 31);
			this.buttonClear.TabIndex = 6;
			this.buttonClear.Text = "Clear Log";
			this.buttonClear.UseVisualStyleBackColor = true;
			this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
			// 
			// numericUpDownCheckBreakTime
			// 
			this.numericUpDownCheckBreakTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.numericUpDownCheckBreakTime.Location = new System.Drawing.Point(268, 20);
			this.numericUpDownCheckBreakTime.Margin = new System.Windows.Forms.Padding(4);
			this.numericUpDownCheckBreakTime.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
			this.numericUpDownCheckBreakTime.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.numericUpDownCheckBreakTime.Name = "numericUpDownCheckBreakTime";
			this.numericUpDownCheckBreakTime.Size = new System.Drawing.Size(56, 18);
			this.numericUpDownCheckBreakTime.TabIndex = 7;
			this.numericUpDownCheckBreakTime.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.numericUpDownCheckBreakTime.ValueChanged += new System.EventHandler(this.numericUpDownCheckBreakTime_ValueChanged);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(166, 20);
			this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(94, 16);
			this.label3.TabIndex = 8;
			this.label3.Text = "Wait for Break:";
			// 
			// buttonMinimize
			// 
			this.buttonMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.buttonMinimize.ForeColor = System.Drawing.Color.LimeGreen;
			this.buttonMinimize.Location = new System.Drawing.Point(1263, 50);
			this.buttonMinimize.Margin = new System.Windows.Forms.Padding(4);
			this.buttonMinimize.Name = "buttonMinimize";
			this.buttonMinimize.Size = new System.Drawing.Size(100, 31);
			this.buttonMinimize.TabIndex = 9;
			this.buttonMinimize.Text = "Minimize";
			this.buttonMinimize.UseVisualStyleBackColor = true;
			this.buttonMinimize.Click += new System.EventHandler(this.buttonMinimize_Click);
			// 
			// textBoxStatistic
			// 
			this.textBoxStatistic.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.textBoxStatistic.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBoxStatistic.Font = new System.Drawing.Font("Courier New", 10.18868F);
			this.textBoxStatistic.Location = new System.Drawing.Point(0, 0);
			this.textBoxStatistic.Margin = new System.Windows.Forms.Padding(4);
			this.textBoxStatistic.Multiline = true;
			this.textBoxStatistic.Name = "textBoxStatistic";
			this.textBoxStatistic.ReadOnly = true;
			this.textBoxStatistic.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.textBoxStatistic.Size = new System.Drawing.Size(470, 595);
			this.textBoxStatistic.TabIndex = 10;
			this.textBoxStatistic.WordWrap = false;
			// 
			// buttonClearStatistic
			// 
			this.buttonClearStatistic.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.buttonClearStatistic.ForeColor = System.Drawing.Color.Brown;
			this.buttonClearStatistic.Location = new System.Drawing.Point(16, 50);
			this.buttonClearStatistic.Margin = new System.Windows.Forms.Padding(4);
			this.buttonClearStatistic.Name = "buttonClearStatistic";
			this.buttonClearStatistic.Size = new System.Drawing.Size(117, 31);
			this.buttonClearStatistic.TabIndex = 12;
			this.buttonClearStatistic.Text = "Clear Stat";
			this.buttonClearStatistic.UseVisualStyleBackColor = true;
			this.buttonClearStatistic.Click += new System.EventHandler(this.buttonClearStatistic_Click);
			// 
			// splitContainer1
			// 
			this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.Location = new System.Drawing.Point(0, 98);
			this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
			this.splitContainer1.Name = "splitContainer1";
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.textBox1);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.textBoxStatistic);
			this.splitContainer1.Size = new System.Drawing.Size(1379, 599);
			this.splitContainer1.SplitterDistance = 900;
			this.splitContainer1.SplitterWidth = 5;
			this.splitContainer1.TabIndex = 13;
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.numericUpDownEmitTime);
			this.panel1.Controls.Add(this.checkBoxEmit);
			this.panel1.Controls.Add(this.numericUpDownSumStatDayCount);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.buttonClearStatistic);
			this.panel1.Controls.Add(this.buttonClear);
			this.panel1.Controls.Add(this.buttonMinimize);
			this.panel1.Controls.Add(this.numericUpDownCheckBreakTime);
			this.panel1.Controls.Add(this.buttonHide);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.comboBox2);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.comboBox1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Margin = new System.Windows.Forms.Padding(4);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1379, 98);
			this.panel1.TabIndex = 14;
			// 
			// numericUpDownEmitTime
			// 
			this.numericUpDownEmitTime.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.numericUpDownEmitTime.Location = new System.Drawing.Point(487, 24);
			this.numericUpDownEmitTime.Margin = new System.Windows.Forms.Padding(4);
			this.numericUpDownEmitTime.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
			this.numericUpDownEmitTime.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.numericUpDownEmitTime.Name = "numericUpDownEmitTime";
			this.numericUpDownEmitTime.Size = new System.Drawing.Size(56, 18);
			this.numericUpDownEmitTime.TabIndex = 16;
			this.numericUpDownEmitTime.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.numericUpDownEmitTime.ValueChanged += new System.EventHandler(this.numericUpDownEmitTime_ValueChanged);
			// 
			// checkBoxEmit
			// 
			this.checkBoxEmit.AutoSize = true;
			this.checkBoxEmit.Location = new System.Drawing.Point(411, 22);
			this.checkBoxEmit.Name = "checkBoxEmit";
			this.checkBoxEmit.Size = new System.Drawing.Size(69, 20);
			this.checkBoxEmit.TabIndex = 15;
			this.checkBoxEmit.Text = "Active:";
			this.checkBoxEmit.UseVisualStyleBackColor = true;
			this.checkBoxEmit.CheckedChanged += new System.EventHandler(this.checkBoxEmit_CheckedChanged);
			// 
			// numericUpDownSumStatDayCount
			// 
			this.numericUpDownSumStatDayCount.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.numericUpDownSumStatDayCount.Location = new System.Drawing.Point(315, 53);
			this.numericUpDownSumStatDayCount.Margin = new System.Windows.Forms.Padding(4);
			this.numericUpDownSumStatDayCount.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
			this.numericUpDownSumStatDayCount.Name = "numericUpDownSumStatDayCount";
			this.numericUpDownSumStatDayCount.Size = new System.Drawing.Size(56, 18);
			this.numericUpDownSumStatDayCount.TabIndex = 13;
			this.numericUpDownSumStatDayCount.ValueChanged += new System.EventHandler(this.numericUpDownSumStatDayCount_ValueChanged);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(166, 53);
			this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(141, 16);
			this.label4.TabIndex = 14;
			this.label4.Text = "Show statistic for days:";
			// 
			// buttonHide
			// 
			this.buttonHide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonHide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.buttonHide.ForeColor = System.Drawing.SystemColors.AppWorkspace;
			this.buttonHide.Location = new System.Drawing.Point(1361, 12);
			this.buttonHide.Margin = new System.Windows.Forms.Padding(4);
			this.buttonHide.Name = "buttonHide";
			this.buttonHide.Size = new System.Drawing.Size(13, 14);
			this.buttonHide.TabIndex = 5;
			this.buttonHide.Text = "Hide";
			this.buttonHide.UseVisualStyleBackColor = true;
			this.buttonHide.Visible = false;
			this.buttonHide.Click += new System.EventHandler(this.buttonHide_Click);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1379, 727);
			this.Controls.Add(this.splitContainer1);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this.panel1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4);
			this.MinimumSize = new System.Drawing.Size(1000, 395);
			this.Name = "MainForm";
			this.Text = "Break Manager";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownCheckBreakTime)).EndInit();
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel1.PerformLayout();
			this.splitContainer1.Panel2.ResumeLayout(false);
			this.splitContainer1.Panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
			this.splitContainer1.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownEmitTime)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDownSumStatDayCount)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel statusLabelActivityTime;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel statusLabelBreakTime;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel statusLabelState;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.NumericUpDown numericUpDownCheckBreakTime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonMinimize;
        private System.Windows.Forms.TextBox textBoxStatistic;
        private System.Windows.Forms.Button buttonClearStatistic;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel statusLabelCurWindow;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonHide;
        private System.Windows.Forms.NumericUpDown numericUpDownSumStatDayCount;
        private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
		private System.Windows.Forms.ToolStripStatusLabel statusLabelEmitCount;
		private System.Windows.Forms.CheckBox checkBoxEmit;
		private System.Windows.Forms.NumericUpDown numericUpDownEmitTime;
	}
}


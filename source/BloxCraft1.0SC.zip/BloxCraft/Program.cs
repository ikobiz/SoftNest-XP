﻿using System;
using System.Text;
using System.Threading;

namespace Bloxcraft
{
    class Program
    {
        static int width = 400;
        static int height = 100;
        static int viewWidth = 80;
        static int viewHeight = 25;

        static char[,] world = new char[height, width];
        static char[,] renderBuffer = new char[viewHeight, viewWidth];
        static int playerX = width / 2;
        static int playerY = 11;
        static int dirtCount = 0;
        static int stoneCount = 0;
        static bool redrawNeeded = true;
        static bool placingDirt = false;
        static bool placingStone = false;

        static void Main()
        {
            Console.CursorVisible = false;
            InitializeWorld();

            while (true)
            {
                ApplyGravity();

                if (redrawNeeded)
                {
                    Console.SetCursorPosition(0, 0);
                    DrawHUD();
                    DrawWorld();
                    redrawNeeded = false;
                }

                if (Console.KeyAvailable)
                {
                    ConsoleKeyInfo keyInfo = Console.ReadKey(true);
                    if (keyInfo.Key == ConsoleKey.Escape) break;
                    HandleInput(keyInfo);
                }

                Thread.Sleep(30);
            }
        }

        static void InitializeWorld()
        {
            Random rand = new Random();

            for (int x = 0; x < width; x++)
            {
                int groundY;

                if (x < width / 3)
                {
                    // Forest
                    groundY = 15 + rand.Next(-2, 2);
                }
                else if (x < 2 * width / 3)
                {
                    // Mountain
                    double d = (x - width / 2.0) / 15.0;
                    groundY = (int)(10 + d * d + rand.Next(-1, 2));
                }
                else
                {
                    // Desert with downward curve
                    double d = (x - 2.5 * width / 3) / 15.0;
                    groundY = (int)(17 + d * d + rand.Next(-2, 2));
                }

                for (int y = 0; y < height; y++)
                {
                    if (y < groundY)
                        world[y, x] = '.'; // Sky
                    else if (y == groundY)
                    {
                        if (x < width / 3)
                            world[y, x] = '#'; // Grass
                        else if (x > 2 * width / 3)
                            world[y, x] = '~'; // Sand
                        else if (y < 14)
                            world[y, x] = '*'; // Snow peak
                        else
                            world[y, x] = '#'; // Edge terrain
                    }
                    else if (y <= groundY + 2)
                        world[y, x] = '='; // Dirt
                    else if (y < height - 6)
                        world[y, x] = '▒'; // Stone
                    else
                        world[y, x] = '■'; // Bedrock
                }

                // Trees in forest
                if (x < width / 3 && rand.NextDouble() < 0.06)
                {
                    int gy = 0;
                    for (int y = 0; y < height; y++)
                        if (world[y, x] == '#') { gy = y; break; }

                    for (int i = 1; i <= 3; i++)
                        if (gy - i >= 0)
                            world[gy - i, x] = 'T';
                }

                // Cacti in desert
                if (x > 2 * width / 3 && rand.NextDouble() < 0.05)
                {
                    int gy = 0;
                    for (int y = 0; y < height; y++)
                        if (world[y, x] == '~') { gy = y; break; }

                    for (int i = 1; i <= 2; i++)
                        if (gy - i >= 0)
                            world[gy - i, x] = '|';
                }
            }
        }
        static void DrawHUD()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"Inventory → Dirt: {dirtCount}, Stone: {stoneCount}");
            Console.WriteLine("WASD = move | Q/E = hop | Ctrl+Q/E = long hop | Arrows = dig | Z/X + Arrow = place | ESC = quit\n");
            Console.ResetColor();
        }
        static void DrawWorld()
        {
            int offsetX = Math.Max(0, playerX - viewWidth / 2);
            int offsetY = Math.Max(0, playerY - viewHeight / 2);
            offsetX = Math.Min(offsetX, width - viewWidth);
            offsetY = Math.Min(offsetY, height - viewHeight);

            Console.SetCursorPosition(0, 3); // Skip over HUD

            for (int y = 0; y < viewHeight; y++)
            {
                for (int x = 0; x < viewWidth; x++)
                {
                    int worldX = offsetX + x;
                    int worldY = offsetY + y;

                    if (worldX == playerX && worldY == playerY)
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Write('@');
                        continue;
                    }

                    if (worldX >= 0 && worldX < width && worldY >= 0 && worldY < height)
                    {
                        char tile = world[worldY, worldX];
                        switch (tile)
                        {
                            case '.': Console.ForegroundColor = ConsoleColor.White; Console.Write('.'); break;
                            case '#': Console.ForegroundColor = ConsoleColor.Green; Console.Write('■'); break;
                            case '=': Console.ForegroundColor = ConsoleColor.DarkYellow; Console.Write('■'); break;
                            case '▒': Console.ForegroundColor = ConsoleColor.Gray; Console.Write('■'); break;
                            case '■': Console.ForegroundColor = ConsoleColor.DarkGray; Console.Write('■'); break;
                            case '*': Console.ForegroundColor = ConsoleColor.Cyan; Console.Write('■'); break;
                            case '~': Console.ForegroundColor = ConsoleColor.Yellow; Console.Write('■'); break;
                            case 'T': Console.ForegroundColor = ConsoleColor.DarkGreen; Console.Write('■'); break;
                            case '|': Console.ForegroundColor = ConsoleColor.Green; Console.Write('■'); break;
                            default: Console.ForegroundColor = ConsoleColor.White; Console.Write(tile); break;
                        }
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Write(' ');
                    }
                }
                Console.WriteLine();
            }

            Console.ResetColor();
        }



        static void HandleInput(ConsoleKeyInfo keyInfo)
        {
            ConsoleKey key = keyInfo.Key;
            bool ctrl = (keyInfo.Modifiers & ConsoleModifiers.Control) != 0;

            if (placingDirt || placingStone)
            {
                int dx = 0, dy = 0;
                switch (key)
                {
                    case ConsoleKey.UpArrow: dy = -1; break;
                    case ConsoleKey.DownArrow: dy = 1; break;
                    case ConsoleKey.LeftArrow: dx = -1; break;
                    case ConsoleKey.RightArrow: dx = 1; break;
                    default:
                        placingDirt = placingStone = false;
                        return;
                }

                int tx = playerX + dx;
                int ty = playerY + dy;

                if (CanPlace(tx, ty))
                {
                    if (placingDirt && dirtCount > 0)
                    {
                        world[ty, tx] = '=';
                        dirtCount--;
                        redrawNeeded = true;
                    }
                    else if (placingStone && stoneCount > 0)
                    {
                        world[ty, tx] = '▒';
                        stoneCount--;
                        redrawNeeded = true;
                    }
                }

                placingDirt = placingStone = false;
                return;
            }

            int newX = playerX;
            int newY = playerY;

            switch (key)
            {
                case ConsoleKey.W:
                    if (IsAir(playerX, playerY - 1)) { playerY--; redrawNeeded = true; }
                    break;
                case ConsoleKey.S: newY++; break;
                case ConsoleKey.A: newX--; break;
                case ConsoleKey.D: newX++; break;
                case ConsoleKey.Spacebar: TryDig(playerX, playerY + 1); redrawNeeded = true; return;
                case ConsoleKey.Q:
                    TryHop(ctrl ? -2 : -1, -1 * (ctrl ? 2 : 1));
                    return;
                case ConsoleKey.E:
                    TryHop(ctrl ? 2 : 1, -1 * (ctrl ? 2 : 1));
                    return;
                case ConsoleKey.Z: placingDirt = true; return;
                case ConsoleKey.X: placingStone = true; return;
                case ConsoleKey.UpArrow: TryDig(playerX, playerY - 1); redrawNeeded = true; return;
                case ConsoleKey.DownArrow: TryDig(playerX, playerY + 1); redrawNeeded = true; return;
                case ConsoleKey.LeftArrow: TryDig(playerX - 1, playerY); redrawNeeded = true; return;
                case ConsoleKey.RightArrow: TryDig(playerX + 1, playerY); redrawNeeded = true; return;
            }

            if (IsAir(newX, newY))
            {
                playerX = newX;
                playerY = newY;
                redrawNeeded = true;
            }
        }

        static void TryHop(int dx, int dy)
        {
            int tx = playerX + dx;
            int ty = playerY + dy;

            if (IsAir(tx, ty))
            {
                playerX = tx;
                playerY = ty;
                redrawNeeded = true;
            }
        }

        static void TryDig(int x, int y)
        {
            if (x < 0 || x >= width || y < 0 || y >= height) return;

            char tile = world[y, x];
            if (tile == '#' || tile == '*') world[y, x] = '.';
            else if (tile == '=')
            {
                dirtCount++;
                world[y, x] = ' ';
            }
            else if (tile == '▒')
            {
                stoneCount++;
                world[y, x] = ' ';
            }
        }

        static void ApplyGravity()
        {
            while (playerY + 1 < height && IsAir(playerX, playerY + 1))
            {
                playerY++;
                redrawNeeded = true;
            }
        }

        static bool IsAir(int x, int y)
        {
            if (x < 0 || x >= width || y < 0 || y >= height) return false;
            char tile = world[y, x];
            return tile == '.' || tile == ' ';
        }

        static bool CanPlace(int x, int y)
        {
            return IsAir(x, y);
        }
    }
}
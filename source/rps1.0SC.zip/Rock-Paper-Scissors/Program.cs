﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace Rock_Paper_Scissors
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to rock paper scissors game against your computer!");
            Console.ReadKey();
            User_input();
        }

        public static bool Rock = false;
        public static bool Paper = false;
        public static bool Scissors = false;

        static void User_input()
        {
            Console.WriteLine("Please choose a number:");
            Console.WriteLine("1) Rock");
            Console.WriteLine("2) Paper");
            Console.WriteLine("3) Scissors");
            string choice = Console.ReadLine();
            switch (choice)
            {
                case "1": Rock = true; break;
                case "2": Paper = true; break;
                case "3": Scissors = true; break;
                default: Console.WriteLine("Invalid option. try again."); User_input(); break;
            }
            Computer_input();
        }

        public static bool cRock = false;
        public static bool cPaper = false;
        public static bool cScissors = false;
        static Random rnd = new Random(); // Outside of methods
        static void Computer_input()
        {
            int cChoice = rnd.Next(1, 4);
            if (cChoice == 1)
            {
                cRock = true;
            }
            if (cChoice == 2)
            {
                cPaper = true;
            }
            if (cChoice == 3)
            {
                cScissors = true;
            }

            Logic();
        }

        #region Logic

        static void Logic()
        {
            if (Rock)
            {
                if (cRock)
                {
                    Console.WriteLine("It's a draw!");
                    Console.ReadKey();  
                }
                if (cPaper)
                {
                    Console.WriteLine("Computer Wins!");
                    Console.ReadKey();
                }
                if (cScissors)
                {
                    Console.WriteLine("You Win!");
                    Console.ReadKey();
                }
            }
            if (Paper)
            {
                if (cRock)
                {
                    Console.WriteLine("You Win!");
                    Console.ReadKey();
                }
                if (cPaper)
                {
                    Console.WriteLine("It's a draw!");
                    Console.ReadKey();
                }
                if (cScissors)
                {
                    Console.WriteLine("Computer Wins!");
                    Console.ReadKey();
                }
            }

            if (Scissors)
            {
                if (cRock)
                {
                    Console.WriteLine("Computer Wins!");
                    Console.ReadKey();
                }
                if (cPaper)
                {
                    Console.WriteLine("You Win!");
                    Console.ReadKey();
                }
                if (cScissors)
                {
                    Console.WriteLine("It's a draw!");
                    Console.ReadKey();
                }
            }

        }

        #endregion
    }
}
